package com.usk.ecommerce.service;

import com.usk.ecommerce.dto.LoginRequest;
import com.usk.ecommerce.dto.UserRegisterRequest;
import com.usk.ecommerce.model.User;

import javax.validation.Valid;

public interface UserService {

	User registerUser(@Valid UserRegisterRequest request);

	String loginUser(@Valid LoginRequest request);

}
