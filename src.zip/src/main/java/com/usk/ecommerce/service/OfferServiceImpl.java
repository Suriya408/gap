package com.usk.ecommerce.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usk.ecommerce.dto.ApplicationResponseDto;
import com.usk.ecommerce.dto.OfferDto;
import com.usk.ecommerce.model.Offers;
import com.usk.ecommerce.repository.OfferRepository;

@Service
public class OfferServiceImpl implements OfferService {
	@Autowired
	private OfferRepository offerRepository;

	@Override
	public ApplicationResponseDto addOfferCode(OfferDto offerdto) {

		Offers offer = new Offers();
		BeanUtils.copyProperties(offerdto, offer);
		ApplicationResponseDto response = new ApplicationResponseDto();
		offerRepository.save(offer);
		response.setStatusCode(1000);
		response.setMessage("Saved Successfully");
		response.setData(offer);
		return response;

	}

	@Override
	public OfferDto getOfferByCode(String code) {
		Offers offer = offerRepository.findByOfferCode(code);
		OfferDto dto = new OfferDto();
		dto.setOfferCode(offer.getOfferCode());
		dto.setDiscountType(offer.getDiscountType());
		dto.setValue(offer.getValue());
		dto.setMinOrderAmount(offer.getMinOrderAmount());
		dto.setExpiryDate(offer.getExpiryDate());
		return dto;
	}

	@Override
	public ApplicationResponseDto deleteOffer(String code) {
		Offers existing = offerRepository.findById(code)
				.orElseThrow(() -> new RuntimeException("Offer code not found"));
		offerRepository.delete(existing);
		ApplicationResponseDto response = new ApplicationResponseDto();
		response.setStatusCode(1000);
		response.setMessage("Offer code deleted successfully");
		response.setData(code);
		return response;
	}

	@Override
	public List<OfferDto> getAllOffers() {
		List<Offers> offers = offerRepository.findAll();
		List<OfferDto> offerDtos = new ArrayList<>();
		for (Offers offer : offers) {
			OfferDto dto = new OfferDto();
			dto.setOfferCode(offer.getOfferCode());
			dto.setDiscountType(offer.getDiscountType());
			dto.setValue(offer.getValue());
			dto.setMinOrderAmount(offer.getMinOrderAmount());
			dto.setExpiryDate(offer.getExpiryDate());
			offerDtos.add(dto);
		}

		return offerDtos;
	}

}
