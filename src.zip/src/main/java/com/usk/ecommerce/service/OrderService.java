package com.usk.ecommerce.service;

import com.usk.ecommerce.model.Order;

public interface OrderService {

	Order purchase(String userId, Long accountNumber);

	

}
