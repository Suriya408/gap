package com.usk.ecommerce.service;

import java.util.List;

import com.usk.ecommerce.dto.ApplicationResponseDto;
import com.usk.ecommerce.dto.OfferDto;

public interface OfferService {

	ApplicationResponseDto addOfferCode(OfferDto offer);

	public List<OfferDto> getAllOffers();

	public OfferDto getOfferByCode(String code);

	public ApplicationResponseDto deleteOffer(String code);

}
