package com.usk.ecommerce.service;

import java.util.List;

import com.usk.ecommerce.model.CartItem;

public interface CartService {

	CartItem addToCart(String userId, String productId, int quantity);

	List<CartItem> viewCart(String userId);

	void removeFromCart(String cartItemId);

}
