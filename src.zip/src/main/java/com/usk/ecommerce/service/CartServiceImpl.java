package com.usk.ecommerce.service;

import java.util.List;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usk.ecommerce.controller.CartController;
import com.usk.ecommerce.model.CartItem;
import com.usk.ecommerce.model.Product;
import com.usk.ecommerce.repository.CartRepository;
import com.usk.ecommerce.repository.ProductRepository;

@Service
public class CartServiceImpl implements CartService {

	Logger logger = LoggerFactory.getLogger(CartServiceImpl.class);

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private ProductRepository productRepository;

	@Override
	public CartItem addToCart(String userId, String productId, int quantity) {
		ObjectId productObjectId = new ObjectId(productId);
		logger.info("CartController service impl addtocart ");
		Product product = productRepository.findById(String.valueOf(productObjectId))
				.orElseThrow(() -> new RuntimeException("Product not found"));
		CartItem item = new CartItem();
		item.setUserId(userId);
		item.setProduct(product);
		item.setQuantity(quantity);
		return cartRepository.save(item);
	}

	@Override
	public List<CartItem> viewCart(String userId) {
		logger.info("CartController service impl view ");
		return (List<CartItem>) cartRepository.findByUserId(userId);
	}

	@Override
	public void removeFromCart(String cartItemId) {
		logger.info("CartController Service impl Delete ");
		cartRepository.deleteById(cartItemId);
	}

}
