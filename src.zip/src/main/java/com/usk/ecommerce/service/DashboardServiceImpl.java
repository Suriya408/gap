package com.usk.ecommerce.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usk.ecommerce.repository.OrderRepository;

@Service
public class DashboardServiceImpl implements DashboardService {
	
	
	@Autowired
    private OrderRepository orderRepository;
 
    @Override
    public Double getMonthlySales(int month, int year) {
        return orderRepository.getTotalSalesByMonth(month, year);
    }
 
    @Override
    public Long getMonthlyOrderCount(int month, int year) {
        return orderRepository.getOrderCountByMonth(month, year);
    }
 
    @Override
    public Long getMonthlyProductsSold(int month, int year) {
        return orderRepository.getTotalProductsSoldByMonth(month, year);
    }
 
    @Override
    public List<Map<String, Object>> getMonthlySalesReport(int year) {
        List<Object[]> results = orderRepository.getMonthlySalesByYear(year);
        List<Map<String, Object>> response = new ArrayList<>();
        for (Object[] row : results) {
            Map<String, Object> map = new HashMap<>();
            map.put("month", row[0]);
            map.put("sales", row[1]);
            response.add(map);
        }
        return response;
    }
 
    @Override
    public List<Map<String, Object>> getTopProducts(int month, int year) {
        List<Object[]> results = orderRepository.getTopSellingProducts(month, year);
        List<Map<String, Object>> response = new ArrayList<>();
        for (Object[] row : results) {
            Map<String, Object> map = new HashMap<>();
            map.put("product", row[0]);
            map.put("totalSold", row[1]);
            response.add(map);
        }
        return response;
    }
    
    @Override
    public List<Map<String, Object>> getRevenueByCategory(int month, int year) {
        List<Object[]> results = orderRepository.getRevenueByCategory(month, year);
        List<Map<String, Object>> response = new ArrayList<>();
        for (Object[] row : results) {
            Map<String, Object> map = new HashMap<>();
            map.put("category", row[0]);
            map.put("revenue", row[1]);
            response.add(map);
        }
        return response;
    }

}
