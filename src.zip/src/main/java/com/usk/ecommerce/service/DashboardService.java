package com.usk.ecommerce.service;

import java.util.List;
import java.util.Map;

public interface DashboardService {
	
	
	Double getMonthlySales(int month, int year);
    Long getMonthlyOrderCount(int month, int year);
    Long getMonthlyProductsSold(int month, int year);
    List<Map<String, Object>> getMonthlySalesReport(int year);
    List<Map<String, Object>> getTopProducts(int month, int year);
    List<Map<String, Object>> getRevenueByCategory(int month, int year);

}
