package com.usk.ecommerce.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usk.ecommerce.controller.UserController;
import com.usk.ecommerce.dto.LoginRequest;
import com.usk.ecommerce.dto.UserRegisterRequest;
import com.usk.ecommerce.model.User;
import com.usk.ecommerce.repository.UserRepository;



@Service
public class UserServiceimpl implements UserService {

	Logger logger = LoggerFactory.getLogger(UserServiceimpl.class);
	
	@Autowired
    private UserRepository userRepository;
 

    public User registerUser(UserRegisterRequest request) {
    	
    	logger.info("UserServiceimpl registerUser ");
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Email already registered.");
        }
 
        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(request.getPassword()); 
        user.setMobile(request.getMobile());
 
        return userRepository.save(user);
    }


    @Override
    public String loginUser(LoginRequest request) {
    	
    	
    	logger.info("UserServiceimpl loginUser ");

        User user = userRepository.findByEmail(request.getEmail())

                .orElseThrow(() -> new RuntimeException("Invalid email or password."));
 
        if (!user.getPassword().equals(request.getPassword())) {

            throw new RuntimeException("Invalid email or password.");

        }
 
        return "Login successful for user: " + user.getName();

    }
 
}
