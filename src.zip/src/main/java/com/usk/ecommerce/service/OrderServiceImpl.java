package com.usk.ecommerce.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.usk.ecommerce.client.BankClient;
import com.usk.ecommerce.dto.AccountResponse;
import com.usk.ecommerce.dto.PaymentRequest;
import com.usk.ecommerce.dto.PaymentResponse;
import com.usk.ecommerce.model.CartItem;
import com.usk.ecommerce.model.Offers;
import com.usk.ecommerce.model.Order;
import com.usk.ecommerce.model.OrderItem;
import com.usk.ecommerce.repository.CartRepository;
import com.usk.ecommerce.repository.OfferRepository;
import com.usk.ecommerce.repository.OrderItemRepository;
import com.usk.ecommerce.repository.OrderRepository;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private CartRepository cartRepository;

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private OfferRepository offerRepository;

	@Autowired
	private OrderItemRepository orderItemRepository;

	@Autowired
	private BankClient bankClient;

	@Override
	public Order purchase(String userId, Long accountNumber) {
		List<CartItem> cartItems = cartRepository.findByUserId(userId);
		if (cartItems.isEmpty()) {
			throw new RuntimeException("Cart is empty.");
		}

		double total = cartItems.stream().mapToDouble(item -> item.getProduct().getPrice() * item.getQuantity()).sum();

		List<Offers> codes = getAvailableOffers(total);

		double offerAmount = applyAllOffers(codes, total);

		checkoutCart(userId, offerAmount);

		Order order = new Order();

		order.setUserId(userId);

		order.setOrderDate(LocalDateTime.now());

		order.setTotalAmount(total);

		List<OrderItem> orderItems = cartItems.stream().map(cartItem -> {

			OrderItem item = new OrderItem();

			item.setOrder(order);

			item.setProduct(cartItem.getProduct());

			item.setQuantity(cartItem.getQuantity());

			item.setPrice(cartItem.getProduct().getPrice());

			return item;

		}).collect(Collectors.toList());

		order.setItems(orderItems);

		Order savedOrder = orderRepository.save(order);

		orderItemRepository.saveAll(orderItems);

		cartRepository.deleteAll(cartItems);

		return savedOrder;

	}

	public PaymentResponse checkoutCart(String userId, Double totalAmount) {

		PaymentRequest request = new PaymentRequest();
		request.setUserId(userId);
		request.setAmount(totalAmount);

		PaymentResponse response = bankClient.processPayment(request);

		if (!response.isSuccess()) {
			throw new RuntimeException("Status: " + response.getMessage());
		}
		return response;

	}

	public List<Offers> getAvailableOffers(double orderAmount) {
		LocalDate today = LocalDate.now();
		return offerRepository.findByMinOrderAmountLessThanEqualAndExpiryDateGreaterThanEqual(orderAmount, today);
	}

	public double applyAllOffers(List<Offers> offers, double total) {
		double finalAmount = total;

		for (Offers offer : offers) {
			if ("percentage".equalsIgnoreCase(offer.getDiscountType())) {
				finalAmount = finalAmount - ((finalAmount * offer.getValue()) / 100);
			} else {
				finalAmount = finalAmount - offer.getValue();
			}

			// Ensure below zero
			if (finalAmount < 0) {
				finalAmount = 0;
				break;
			}
		}

		return finalAmount;
	}

}
