package com.usk.ecommerce.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usk.ecommerce.dto.ApplicationResponseDto;
import com.usk.ecommerce.model.Product;
import com.usk.ecommerce.repository.ProductRepository;

@Service
public class ProductServiceimpl implements ProductService {

	Logger logger = LoggerFactory.getLogger(ProductServiceimpl.class);

	@Autowired
	ProductRepository productRepository;

	@Override
	public List<Product> searchByName(String keyword) {
		logger.info("ProductServiceimpl searchByname");
		return productRepository.findByNameContainingIgnoreCase(keyword);
	}

	@Override
	public List<Product> searchByCategory(String category) {
		logger.info("ProductServiceimpl searchByCategory");
		return productRepository.findByCategoryIgnoreCase(category);
	}

	@Override
	public List<Product> searchByPriceRange(double min, double max) {
		logger.info("ProductServiceimpl searchByPriceRange");
		return productRepository.findByPriceBetween(min, max);
	}

	@Override
	public ApplicationResponseDto saveProduct(String name, String category, String description, double price) {

		Product product = new Product();
		product.setCategory(category);
		product.setName(name);
		product.setDescription(description);
		product.setPrice(price);
		ApplicationResponseDto response = new ApplicationResponseDto();
		productRepository.save(product);
		response.setStatusCode(1000);
		response.setMessage("Login Successfully");
		response.setData(product);
		return response;

	}
}
