package com.usk.ecommerce.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.usk.ecommerce.service.DashboardService;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

	
	@Autowired
    private DashboardService dashboardService;
 
    @GetMapping("/sales")
    public Double getMonthlySales(@RequestParam int month, @RequestParam int year) {
        return dashboardService.getMonthlySales(month, year);
    }
 
    @GetMapping("/orders")
    public Long getMonthlyOrders(@RequestParam int month, @RequestParam int year) {
        return dashboardService.getMonthlyOrderCount(month, year);
    }
 
    @GetMapping("/products-sold")
    public Long getMonthlyProductsSold(@RequestParam int month, @RequestParam int year) {
        return dashboardService.getMonthlyProductsSold(month, year);
    }
 
    @GetMapping("/sales-report")
    public List<Map<String, Object>> getMonthlySalesReport(@RequestParam int year) {
        return dashboardService.getMonthlySalesReport(year);
    }
 
    @GetMapping("/top-products")
    public List<Map<String, Object>> getTopProducts(@RequestParam int month, @RequestParam int year) {
        return dashboardService.getTopProducts(month, year);
    }
 
    @GetMapping("/category-revenue")
    public List<Map<String, Object>> getCategoryRevenue(@RequestParam int month, @RequestParam int year) {
        return dashboardService.getRevenueByCategory(month, year);
    }
}
