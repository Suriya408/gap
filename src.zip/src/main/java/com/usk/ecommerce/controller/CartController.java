package com.usk.ecommerce.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.usk.ecommerce.model.CartItem;
import com.usk.ecommerce.service.CartService;



@RestController
@RequestMapping("/api/cart")
public class CartController {

	
	Logger logger = LoggerFactory.getLogger(CartController.class);
	
	@Autowired
    private CartService cartService;
 
    @PostMapping("/add")
    public CartItem addToCart(@RequestParam String userId,
                              @RequestParam String productId,
                              @RequestParam int quantity) {
    	
    	logger.info("CartController /add ");
        return cartService.addToCart(userId, productId, quantity);
    }
 
    @GetMapping("/{userId}")
    public List<CartItem> viewCart(@PathVariable String userId) {
    	logger.info("CartController /userId ");
    	return cartService.viewCart(userId);
    }
 
    @DeleteMapping("/remove/{cartItemId}")
    public String removeFromCart(@PathVariable String cartItemId) {
    	
    	logger.info("CartController Delete ");
        cartService.removeFromCart(cartItemId);
        return "Item removed from cart.";
    }
}
