package com.usk.ecommerce.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

public class OfferDto {

	@NotNull(message = "Offer Code must not be null")
	private String offerCode;

	@NotNull(message = "DiscountType must not be null")
	private String discountType;

	@NotNull(message = "Value must not be null")
	private int value;

	@NotNull(message = "MinOrderAmount must not be null")
	private int minOrderAmount;

	@NotNull(message = "expiryDate must not be null")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate expiryDate;

	public String getOfferCode() {
		return offerCode;
	}

	public void setOfferCode(String offerCode) {
		this.offerCode = offerCode;
	}

	public String getDiscountType() {
		return discountType;
	}

	public void setDiscountType(String discountType) {
		this.discountType = discountType;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public int getMinOrderAmount() {
		return minOrderAmount;
	}

	public void setMinOrderAmount(int minOrderAmount) {
		this.minOrderAmount = minOrderAmount;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

}