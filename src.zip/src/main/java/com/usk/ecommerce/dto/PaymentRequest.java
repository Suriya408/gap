package com.usk.ecommerce.dto;

public class PaymentRequest {

	private String userId;
	private Double amount;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double totalAmount) {
		this.amount = totalAmount;
	}

}