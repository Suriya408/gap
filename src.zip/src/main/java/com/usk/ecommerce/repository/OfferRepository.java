package com.usk.ecommerce.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.usk.ecommerce.model.Offers;

public interface OfferRepository extends MongoRepository<Offers, String> {

	List<Offers> findByMinOrderAmountLessThanEqualAndExpiryDateGreaterThanEqual(double amount, LocalDate today);
	
	Offers findByOfferCode(String code);
}
