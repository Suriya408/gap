package com.usk.ecommerce.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.usk.ecommerce.model.Order;

public interface OrderRepository extends MongoRepository<Order,String> {

	
	@Query("SELECT SUM(o.totalAmount) FROM Order o WHERE MONTH(o.orderDate) = ?1 AND YEAR(o.orderDate) = ?2")
    Double getTotalSalesByMonth(int month, int year);
	
	@Query("SELECT COUNT(o) FROM Order o WHERE MONTH(o.orderDate) = ?1 AND YEAR(o.orderDate) = ?2")
    Long getOrderCountByMonth(int month, int year);
	
	@Query("SELECT SUM(oi.quantity) FROM OrderItem oi WHERE MONTH(oi.order.orderDate) = ?1 AND YEAR(oi.order.orderDate) = ?2")
    Long getTotalProductsSoldByMonth(int month, int year);
	
	@Query("SELECT MONTH(o.orderDate), SUM(o.totalAmount) FROM Order o WHERE YEAR(o.orderDate) = ?1 GROUP BY MONTH(o.orderDate)")
    List<Object[]> getMonthlySalesByYear(int year);
 
    @Query("SELECT oi.product.name, SUM(oi.quantity) as totalSold FROM OrderItem oi WHERE MONTH(oi.order.orderDate) = ?1 AND YEAR(oi.order.orderDate) = ?2 GROUP BY oi.product.name ORDER BY totalSold DESC")
    List<Object[]> getTopSellingProducts(int month, int year);
 
    @Query("SELECT oi.product.category, SUM(oi.quantity * oi.price) FROM OrderItem oi WHERE MONTH(oi.order.orderDate) = ?1 AND YEAR(oi.order.orderDate) = ?2 GROUP BY oi.product.category")
    List<Object[]> getRevenueByCategory(int month, int year);
}
