package com.usk.ecommerce.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.usk.ecommerce.model.OrderItem;

public interface OrderItemRepository extends MongoRepository<OrderItem, String> {

}
