package com.usk.ecommerce.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.usk.ecommerce.model.CartItem;

public interface CartRepository extends MongoRepository<CartItem, String> {

	List<CartItem> findByUserId(String userIdObjectId);

}
