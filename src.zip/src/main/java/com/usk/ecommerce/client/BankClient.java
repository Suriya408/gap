package com.usk.ecommerce.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.usk.ecommerce.dto.AccountResponse;
import com.usk.ecommerce.dto.PaymentRequest;
import com.usk.ecommerce.dto.PaymentResponse;

import io.swagger.v3.oas.annotations.parameters.*;

//@FeignClient(name = "banking-service")
@FeignClient(name = "bank-use-cases", url = "http://localhost:8080/bank")
public interface BankClient {

	@GetMapping("/account/{accountNumber}")
	AccountResponse findAccount(@PathVariable("accountNumber") Long accountNumber);

	@PostMapping("/debit")
	String debitFromAccount(@RequestParam("accountNumber") Long accountNumber, @RequestParam("amount") double amount);

	@PostMapping("/bank/pay")
	PaymentResponse processPayment(@RequestBody PaymentRequest request);

}
